let products;
let categories;

const products_api_url = "http://localhost:3000/products";

const getTDForText = (text) => {
  const td = document.createElement("TD");
  td.appendChild(document.createTextNode(text));
  return td;
}

const getTRForProduct = (product) => {
  const tr = document.createElement("TR");
  tr.appendChild(getTDForText(product.id));
  tr.appendChild(getTDForText(product.title));
  tr.appendChild(getTDForText(product.description));
  tr.dataset.id = product.id;
  return tr;
}

const constructTableFromProducts = (products) => {
  const table_body = document.getElementById("table_products_body");
  products.forEach(product => {
    table_body.appendChild(getTRForProduct(product));
  });

  const input = document.getElementById("pid");
  table_body.childNodes.forEach(row => {
    if(row.nodeName === "TR") {
      row.addEventListener("click", () => {
        input.value = row.dataset.id;
      })
    }
  });
}

const getProducts = () => {
  fetch(products_api_url)
    .then(response => response.json())
    .then(data => {
      console.log(data.products);
      constructTableFromProducts(data.products); 
    })
    .catch((reject) => {
      console.log("Could not load data..." + reject);
    });
}

const doUpdateProduct = () => {
  const id = document.getElementById("pid").value;
  const description = document.getElementById("description").value;
  if(description) {
    fetch("/products/update/", {
      method: "PUT",
      body: JSON.stringify({ id: id, description: description }),
    })
    .then(response => response.json())
    .then(data => {
      alert(data);
    })
    .catch((reject) => {
      console.log("Could not load save new description..." + reject);
    });
  }
  else {
    alert("Description cannot be empty")
  }
}
