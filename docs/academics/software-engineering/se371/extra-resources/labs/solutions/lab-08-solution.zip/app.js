const express = require('express');
const app = express();
const products = require("./data/products");

app.use(express.static("public"));

app.get("/", (request, response) => {
  response.sendFile("/pages/index.html", {root: __dirname});
});

app.get("/products", (request, response) => {
  response.json({products: products.products});
});

app.use((request, response) => {
  response.status(404).json({ error: "Error 404 Resource not found" });
});

app.listen(3000, () => { 
  console.log('Server started at: http://localhost:3000/');
});
