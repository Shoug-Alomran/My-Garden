const express = require('express');
require('dotenv').config();

const db = require("./config/database.js");

const bodyParser = require('body-parser');

const Company = require("./model/company").Company;

const app = express();

app.use(bodyParser.urlencoded({ extended: false }))
app.use(express.static('public'));
app.set("view engine", "ejs");

///////////////////////////////////////////////////
////////////////////   ROUTES    //////////////////
///////////////////////////////////////////////////

// Load all companies from database then render index template with all companies ////
app.get('/', (request, response) => {
  Company.findAll()
    .then(data => {
      response.render('index', { companies: data, error: null });
    })
    .catch(err => {
      response.render('index', { companies: null, error: "Server could not load data" });
    })
});


/// MODIFY THIS ROUTE to ACCEPT ARGUMENTS in the BODY of the HTTP REQUEST 
app.post('/v1/companies/', (request, response) => {
  const { name, address, description, capital, owner} = request.body;
  const newCompany = Company.build({
    "name": name, "address": address, "description": description, "capital": capital, "owner": owner
  });
  newCompany.save()
    .then(data => {
      response.redirect("/");
    })
    .catch(err => {
      response.redirect("/");
    })
});

app.delete('/v1/companies/:companyid', (request, response) => {
  Company.destroy({
    where: {
      id: request.params.companyid
    }
  }).then(data => {
    response.json({ data: data, message:"Object deleted" });
  }).catch(err => {
    response.json({ data: null, message: "Could not delete object" });
  })
});

app.put('/v1/companies/:companyid/:name/:address/:description/:capital/:owner/', (request, response) => {
  const { companyid, name, address, description, capital, owner } = request.params;
  Company.findOne({
    where: { id: companyid }
  }).then(company => {
    if(company){
      company.update({
        "id": companyid, "name": name, "address": address, "description": description, "capital": capital, "owner": owner
      }).then(data => {
        response.json({ data: data, message: "Object updated" });
      }).catch(err => {
        response.json({ data: null, message: "Could not update object" });
      })
    } else{
      response.json({ data: null, message: "Could not update object" });
    }
  }).catch(err => {
    response.json({ data: null, message: "Could not update object" });
  })
});

// Start server, then connect to database
app.listen(process.env.PORT, async () => {
  await db.connectToDB();
  console.log(`Server is listening at http://localhost:${process.env.PORT}`);
});

