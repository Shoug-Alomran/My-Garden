const SERVER_URL = "/v1/companies/";

console.log("index.js executing...");

const addDeleteButtonsHandlers = (deleteButtons) => {
  deleteButtons.forEach(button => {
    button.addEventListener("click", (e) => {
      const id = button.dataset.companyid;
      if (id) {
        fetch(`${SERVER_URL}${id}`, {
          method: "DELETE"
        }).then(result => result.json())
          .then(data => {
            if (data) {
              Swal.fire({
                icon: "success",
                title: "Object deleted",
                text: data.message,
              }).then(answer => {
                window.location = "/";
              })
            } else {
              Swal.fire({
                icon: "error",
                title: "Could not delete object",
                text: data.message,
              });
            }
          })
      }
    })
  });
}

const addUpdateButtonsHandlers = (updateButtons) => {
  updateButtons.forEach(button => {
    button.addEventListener("click", (e) => {
      const id = `${button.dataset.companyid}`;
      const newName = document.getElementById(`td_${id}_name`).textContent;
      const newAddress = document.getElementById(`td_${id}_address`).textContent; 
      const newDescription = document.getElementById(`td_${id}_description`).textContent; 
      const newCapital = document.getElementById(`td_${id}_capital`).textContent; 
      const newOwner = document.getElementById(`td_${id}_owner`).textContent;  
      fetch(`${SERVER_URL}${id}/${newName}/${newAddress}/${newDescription}/${newCapital}/${newOwner}`, {
        method: "PUT"
      }).then(result => result.json())
        .then(data => {
          if (data) {
            Swal.fire({
              icon: "success",
              title: "Object updated",
              text: data.message,
            }).then(answer => {
              window.location = "/";
            })
          } else {
              Swal.fire({
                icon: "error",
                title: "Could not update object",
                text: data.message,
              });
            }
        }).catch(err => {
          Swal.fire({
            icon: "error",
            title: "Could not update object",
            text: err,
          });
        })
    });
  }); 
}

document.addEventListener("DOMContentLoaded", () => {
  const deleteButtons = document.querySelectorAll(".deleteBtn");
  const updateButtons = document.querySelectorAll(".updateBtn");

  addDeleteButtonsHandlers(deleteButtons);
  addUpdateButtonsHandlers(updateButtons);

});