const express = require('express');
require('dotenv').config();
const chairs=require("./data.js");

// express app creation
const app = express();

// Add the public folder as a static files folder (so that files are accessible to client requests)
app.use(express.static('public')); 

// register view engine to express app
app.set('view engine', 'ejs');

// Add routes handlers below
app.get('/', (req, res) => {
  for(let chair of chairs)  {
    console.log(chair.img, chair.alt, chair.name, chair.price);
  }
  res.render('index', {chairs:chairs }); // second argument is data sent to template
});

app.get('/about', (req, res) => {
  res.render('about', {title: 'About us'});
});

// Finally if no route corresponds to request render 404 page
app.use((req, res) => {
  res.status(404).render('404', {title: '404 error'});
});

// listen for requests
app.listen(process.env.PORT, () => { 
  console.log(`Listening on port ${process.env.PORT}...`) 
});
